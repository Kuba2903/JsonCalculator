﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Launcher
{
    public class Data
    {
        public string ObjName { get; set; }
        public string Operator { get; set; }
        public double Value1 { get; set; }
        public double Value2 { get; set; }
        
    }
}
